Train<-read.csv('Train.csv')
Train_AccountInfo<-read.csv('Train_AccountInfo.csv')
Train_Demographics<-read.csv('Train_Demographics.csv')
Train_ServicesOptedFor1<-read.csv('Train_ServicesOptedFor.csv')

str(Train)
str(Train_AccountInfo)
str(Train_Demographics)
str(Train_ServicesOptedFor1)

attach(Train)
attach(Train_AccountInfo)
attach(Train_Demographics)
attach(Train_ServicesOptedFor1)

##Renaming the level HouseholdID to CustomerID in Train_Demographics
colnames(Train_Demographics)[1]<-'CustomerID'

#To sort the datasets based on CustomerID
Train<-Train[order(Train$CustomerID),]
Train_AccountInfo<-Train_AccountInfo[order(Train_AccountInfo$CustomerID),]
Train_Demographics<-Train_Demographics[order(Train_Demographics$CustomerID),]
Train_ServicesOptedFor1<-Train_ServicesOptedFor1[order(Train_ServicesOptedFor1$CustomerID),]

levels(Train_ServicesOptedFor1$TypeOfService)
##There are 9 levels and hence, we will dcast it

library(reshape2)
Train_ServicesOptedFor<-dcast(Train_ServicesOptedFor1, CustomerID~TypeOfService)

##Combining the data
mydata<-cbind.data.frame(Train_Demographics, Train_AccountInfo[,-1], Train_ServicesOptedFor[,-1], Churn=Train[,-1])

##Checking for missing values ##
sum(is.na(mydata))
colSums(is.na(mydata))    ##5 missing values tagged as NA in the attribute 'ContractType'

##Also missing values are tagged as MISSINGVAL and ''(spaces) and '?'
mydata[mydata=='']<-NA
mydata[mydata=='MISSINGVAL']<-NA
mydata[mydata=='?']<-NA

sum(is.na(mydata))
colSums(is.na(mydata))

##Checking the Structure
str(mydata)

library(dplyr)
catdata<-select(mydata, -c(BaseCharges, TotalCharges, Churn))
numdata<-select(mydata, c(BaseCharges, TotalCharges))
Target<-select(mydata, c(Churn))

catdata<-data.frame(apply(catdata, 2, 'factor'))
numdata<-data.frame(apply(numdata, 2, function(x) as.numeric(x)))

str(catdata)
str(numdata)

##Bar-Plots for categoric attributes
# for(i in 1:22){
#   dev.copy(png,filename=paste(names(catdata[i]),"plot.png",sep="_"))
#   plot(catdata[,i], xlab = names(catdata[i]), ylab = 'Frequency')
#   dev.off ()
# }

###Histogram for numeric attributes
# for(i in 1:2){
#   dev.copy(png,filename=paste(names(numdata[i]),"plot.png",sep="_"))
#   hist(numdata[,i],xlab = names(numdata[i]), ylab = 'Frequency')
#   dev.off ()
# }

#Plot of Target
# dev.copy(png, filename = 'Churn_plot.png')
# plot(Target, xlab = 'Churn', ylab = 'Frequency')
# dev.off()

##Box-Plots
# for(i in 1:2){
#   dev.copy(png,filename=paste(names(numdata[i]),"bwplot.png",sep="_"))
#   boxplot(numdata[,i], xlab = names(numdata[i]))
#   dev.off()
# }

##No need of standardization as the units are same for numeric attributes
##Merging catdata, numdata and Target
telecom_data<-cbind.data.frame(catdata,numdata,Target)

sum(is.na(telecom_data))

##Imputing for attributes State and Country as they are always the same
telecom_data[,c('Country','State')]<-centralImputation(telecom_data[,c('Country','State')])

sum(is.na(telecom_data))
colSums(is.na(telecom_data))

telecom_data<-na.omit(telecom_data)
str(telecom_data)

