getwd()

train_data<-read.csv('data6.csv')
test_data<-read.csv('test6.csv')

Output<-test_data$timestamp

y1<-train_data$y1
y2<-train_data$y2
#train_timestamp<-train_data$timestamp

train_data$y1<-NULL
train_data$y2<-NULL
#train_data$timestamp<-NULL

test_data_timestamp<-test_data$timestamp

#test_data$timestamp<-NULL

stock_data<-merge(train_data,test_data,all = T)

sum(is.na(stock_data))
colSums(is.na(stock_data))

#Removing all the columns with more than 40% NAs 
stock_data<-subset(stock_data,select = -c(f_1,f_6,f_22,f_26,f_38,f_49,f_57,f_61,f_63,t_16))

library(vegan)
stock_data<-decostand(stock_data,"standardize")

library(DMwR)
stock_data<-centralImputation(stock_data)
sum(is.na(stock_data))

timestamp<-train_data$timestamp
stock_data$timestamp<-NULL

test<-stock_data[1770:1799,]    #This is the test data after pre-processing
stock_data<-stock_data[1:1769,] #This is the train data after pre-processing

stock_data$y1<-y1      #Adding y1 variable column
stock_data$y2<-y2      #Adding y2 variable column

##Regression
data1<-stock_data
data1$y2<-NULL

set.seed(123)
train_rows<-sample(1:nrow(data1),0.8*nrow(data1))
train_data1<-data1[train_rows,]
validation_data1<-data1[-train_rows,]

lm_model<-lm(y1~.,data = train_data1)
lm_model

AIC(lm_model)
summary(lm_model)

par(mfrow=c(2,2))
plot(lm_model)

library(MASS)
stepout1<-stepAIC(lm_model)
AIC(stepout1)
summary(stepout1)

output_valid1<-predict(stepout1,newdata = validation_data1)
regr.eval(output_valid1,validation_data1$y1)

output_test1<-predict(stepout1,newdata = test)
test$y1<-output_test1
test$y1
#data1$y1

#Using lasso regression
library(glmnet)
train<-as.matrix(data1[,-100])
test<-as.matrix(test)
y1<-data1$y1 

lasso_fit<-glmnet(train,y1,alpha = 1)
plot(lasso_fit,xvar="lambda",label=TRUE)

cv.lasso=cv.glmnet(train,y1)
plot(cv.lasso)

regr.eval(y1, predict(lasso_fit,train))

test<-data.frame(test)

##Classification
data2<-stock_data
data2$y1<-NULL

set.seed(123)
train_rows<-sample(1:nrow(data2),0.75*nrow(data2))
train_data2<-data2[train_rows,]
validation_data2<-data2[-train_rows,]

glm_model<-glm(y2~.,family = 'gaussian',data = train_data2)
glm_model

summary(glm_model)


library(MASS)
#stepout2<-stepAIC(glm_model)

output_validation2<-predict(glm_model,newdata = validation_data2,type = 'response')

library(ROCR)
pred<-prediction(output_validation2,validation_data2$y2)

perf <- performance(pred, measure="tpr", x.measure="fpr")

plot(perf, col=rainbow(10), colorize=T, print.cutoffs.at=seq(0,1,0.05))

perf_auc <- performance(pred, measure="auc")

#auc score from the performance object
auc <- perf_auc@y.values[[1]]
print(auc)

#Predicting class
output_validation2<-ifelse(output_validation2<0.55,0,1)
conf_matrix<-table(true=validation_data2$y2, pred=output_validation2)

accuracy<-sum(diag(conf_matrix))/sum(conf_matrix)
recall<-conf_matrix[2,2]/(conf_matrix[2,2]+conf_matrix[2,1])
precision<-conf_matrix[2,2]/(conf_matrix[2,2]+conf_matrix[1,2]) 
specificity<-conf_matrix[1,1]/(conf_matrix[1,1]+conf_matrix[1,2])

metrics<-c(accuracy,precision,recall,specificity)

output_test2<-predict(glm_model,newdata = test,type = 'response')
output_test2<-ifelse(output_test2<0.5,0,1)
test$y2<-output_test2

##Time series
stock_data$timestamp<-timestamp
y1<-ts(stock_data$y1,frequency = 365)
plot(y1,type="l",lwd=3,col="blue",xlab="timestamp",ylab="y1", main="Time series plot for Book-xyzabc")

decomp<-decompose(y1)
plot(decomp)

library(forecast)
par(mfrow=c(1,2))
acf(y1,lag=30)
pacf(y1,lag=30)

#Applying Auto Arima to forecast
model_arima<-auto.arima(y1,ic='aic')
model_arima
summary(model_arima)

#Box.test(model_arima$residuals, lag = 10, type = "Ljung-Box")

# Let us look at the acf and Pacf graphs to check if
# there are patterns
acf(as.numeric(model_arima$residuals) ,lag.max = 20,
    main = "Residuals ACF plot")
pacf(as.numeric(model_arima$residuals) ,lag.max = 20,
     main = "Residuals PACF plot")

arimaforecast<-forecast(model_arima,h=30)
arimaforecast

Test_forecast<-arimaforecast$mean
#write.csv(Test_forecast,'Test_forecast_using_timeseries.csv')

Test_pred<-test$y1
#write.csv(Test_pred,'Test_pred_using_regression.csv')

Test_pred2<-output_test2
#write.csv(Test_pred2,'Test_pred_using_glm.csv')

plot(forecast(arimaforecast,h=30))
#plot(forecast(Test_pred,h=30))

plot(Test_forecast)
ts.plot(Test_pred)

#library amelia
#library(Amelia)
#missmap(stock_data)
#missing_train<-sapply(stock_data,function(x)all(is.na(x)))

Output<-data.frame(Output)

Output$Timestamp<-test_data_timestamp
Output$y1<-Test_pred
Output$y2<-Test_pred2

Output$Output<-NULL

write.csv(Output,'prediction.csv')
